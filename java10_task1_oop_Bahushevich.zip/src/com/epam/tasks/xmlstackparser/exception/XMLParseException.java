package com.epam.tasks.xmlstackparser.exception;

/**
 * Created by Belarus on 01.12.2015.
 */
public class XMLParseException extends Exception {
    public XMLParseException(String message){
        super(message);
    }
}
